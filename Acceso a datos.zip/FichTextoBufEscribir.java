import java.io.*;

//Actividad IV
public class FichTextoBufEscribir {
    public static void main(String[] args) {
        try {

            FileWriter fic = new FileWriter("FichTexto.txt", true);
            
            BufferedWriter fichero = new BufferedWriter(fic);

            for (int i = 1; i < 11; i++) {
                //escribe una cadena
                fichero.write("Fila numero: " + i); 
                // escribe un salto de línea
                fichero.newLine(); 
            }
            
            fichero.close();

        } catch (FileNotFoundException fn) {
            System.out.println("No se encuentra el fichero");
        } catch (IOException io) {
            System.out.println("Error de E/S ");
        }
    }
}
