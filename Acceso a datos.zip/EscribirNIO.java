import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
//Actividad VI
public class EscribirNIO {
    public static void main(String[] args) {
        Path ruta = Path.of("FichTextoNIO.txt");
        //cadena a escribir
        String cadena = "\nEscribimos una línea usando java.nio.file.";
        try {
            //CREATE: crea un fichero si no existe. Si existe, no lo crea
            Files.writeString(ruta, cadena, StandardOpenOption.CREATE);
            //APPEND: si el fichero existe, agrega los datos al final
            //si no existe se produce una excepción
            Files.writeString(ruta, cadena, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("Error al escribir: " + e.getMessage());
        }
    }
}
