import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//Actividad VII
public class CopiarFicherosBytes {
    public static void main(String[] args) throws IOException {

        FileInputStream in = new FileInputStream(new File("Ffuente.txt"));
        FileOutputStream out = new FileOutputStream(new File("Fdestino.txt"));

        int c;
        while ((c = in.read()) != -1) {
            out.write(c);
        }
        in.close();
        out.close();
    }
}
